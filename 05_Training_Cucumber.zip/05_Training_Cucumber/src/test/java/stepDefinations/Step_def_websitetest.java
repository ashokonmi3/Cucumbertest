package stepDefinations;

import org.junit.runner.RunWith;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
public class Step_def_websitetest {

	@Given("^I launch the website <website>$")
	public void website_launch(String website) throws Throwable {
		// code to navigate to login url
		System.out.println("navigated to login url");
		webdriver wd = new Chromedriver();
		driver.get("www." + website);

	}

	@Given("^The website <website> is launched$")
	public void website_validation(String website) throws Throwable {
		// code to navigate to login url
		System.out.println("navigated to login url");
		webdriver wd= new Chromedriver ();
		String currentURL= driver.getcurrenturl();
		if (currentURL.contains(website) {
			System.out.println("test is pass"):
			else {
				Throw exception("Test failed")
			}
		}

	}
}
